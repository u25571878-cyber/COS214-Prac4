#include "FullCatalogIterator.h"

// Recursive depth-first collection into the snapshot vector
void FullCatalogIterator::buildSnapshot(WorkComponent* node) {
    if (!node) return;

    snapshot.push_back(node);

    // Use Person A's helper (returns a copy of the child pointers)
    std::vector<WorkComponent*> children = node->getChildrenForIteration();
    for (WorkComponent* child : children) {
        buildSnapshot(child);
    }
}

FullCatalogIterator::FullCatalogIterator(WorkComponent* root) : currentIndex(0) {
    buildSnapshot(root);
}

void FullCatalogIterator::first() {
    currentIndex = 0;
}

void FullCatalogIterator::next() {
    if (!isDone()) {
        ++currentIndex;
    }
}

bool FullCatalogIterator::isDone() const {
    return currentIndex >= snapshot.size();
}

WorkComponent* FullCatalogIterator::currentItem() const {
    if (isDone()) return nullptr;
    return snapshot[currentIndex];
}
